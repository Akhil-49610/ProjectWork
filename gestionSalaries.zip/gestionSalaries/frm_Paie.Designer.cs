﻿namespace gestionSalaries
{
    partial class frm_Paie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtppagibig = new System.Windows.Forms.TextBox();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.txtpnetincome = new System.Windows.Forms.TextBox();
            this.Label12 = new System.Windows.Forms.Label();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.txtpgincome = new System.Windows.Forms.TextBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.txtPholPayDay = new System.Windows.Forms.TextBox();
            this.txtPholPay = new System.Windows.Forms.TextBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.txtPregOt = new System.Windows.Forms.TextBox();
            this.txtPRegOtHr = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.txtPrateWage = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.txtPRateperday = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.txtPNoDays = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.txtPPayPeriod = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label19 = new System.Windows.Forms.Label();
            this.txtTotaldeduc = new System.Windows.Forms.TextBox();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.txtPAssignCode = new System.Windows.Forms.DomainUpDown();
            this.txtPEmployeeName = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.txttrancode = new System.Windows.Forms.TextBox();
            this.TabPage9 = new System.Windows.Forms.TabPage();
            this.label20 = new System.Windows.Forms.Label();
            this.txtpsearch = new System.Windows.Forms.TextBox();
            this.dtgParollList = new System.Windows.Forms.DataGridView();
            this.Label15 = new System.Windows.Forms.Label();
            this.TabControl3 = new System.Windows.Forms.TabControl();
            this.TabPage8 = new System.Windows.Forms.TabPage();
            this.PictureBox3 = new System.Windows.Forms.PictureBox();
            this.txtbvale = new System.Windows.Forms.TextBox();
            this.Button2 = new System.Windows.Forms.Button();
            this.btnPsave = new System.Windows.Forms.Button();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.GroupBox7 = new System.Windows.Forms.GroupBox();
            this.txtpremarks = new System.Windows.Forms.RichTextBox();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.GroupBox6 = new System.Windows.Forms.GroupBox();
            this.Label18 = new System.Windows.Forms.Label();
            this.txtpdeducttot = new System.Windows.Forms.TextBox();
            this.Label17 = new System.Windows.Forms.Label();
            this.txtpdeduct4 = new System.Windows.Forms.TextBox();
            this.txtpdeductname4 = new System.Windows.Forms.TextBox();
            this.txtpdeduct3 = new System.Windows.Forms.TextBox();
            this.txtpdeductname3 = new System.Windows.Forms.TextBox();
            this.txtpdeduct2 = new System.Windows.Forms.TextBox();
            this.txtpdeductname2 = new System.Windows.Forms.TextBox();
            this.txtpdeduct1 = new System.Windows.Forms.TextBox();
            this.txtpdeductname1 = new System.Windows.Forms.TextBox();
            this.txtpcadvance = new System.Windows.Forms.TextBox();
            this.txtpphic = new System.Windows.Forms.TextBox();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label14 = new System.Windows.Forms.Label();
            this.GroupBox3.SuspendLayout();
            this.GroupBox4.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.TabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgParollList)).BeginInit();
            this.TabControl3.SuspendLayout();
            this.TabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            this.GroupBox2.SuspendLayout();
            this.GroupBox7.SuspendLayout();
            this.GroupBox5.SuspendLayout();
            this.GroupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtppagibig
            // 
            this.txtppagibig.Location = new System.Drawing.Point(143, 110);
            this.txtppagibig.Margin = new System.Windows.Forms.Padding(4);
            this.txtppagibig.Name = "txtppagibig";
            this.txtppagibig.Size = new System.Drawing.Size(176, 25);
            this.txtppagibig.TabIndex = 8;
            this.txtppagibig.Text = "0";
            this.txtppagibig.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtppagibig.UseWaitCursor = true;
            this.txtppagibig.TextChanged += new System.EventHandler(this.txtppagibig_TextChanged);
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.txtpnetincome);
            this.GroupBox3.Controls.Add(this.Label12);
            this.GroupBox3.Controls.Add(this.GroupBox4);
            this.GroupBox3.Controls.Add(this.txtPrateWage);
            this.GroupBox3.Controls.Add(this.Label9);
            this.GroupBox3.Controls.Add(this.txtPRateperday);
            this.GroupBox3.Controls.Add(this.Label10);
            this.GroupBox3.Controls.Add(this.txtPNoDays);
            this.GroupBox3.Controls.Add(this.Label5);
            this.GroupBox3.Controls.Add(this.txtPPayPeriod);
            this.GroupBox3.Controls.Add(this.Label6);
            this.GroupBox3.Location = new System.Drawing.Point(13, 23);
            this.GroupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.GroupBox3.Size = new System.Drawing.Size(657, 314);
            this.GroupBox3.TabIndex = 2;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Revenu";
            this.GroupBox3.Enter += new System.EventHandler(this.GroupBox3_Enter);
            // 
            // txtpnetincome
            // 
            this.txtpnetincome.BackColor = System.Drawing.Color.White;
            this.txtpnetincome.Enabled = false;
            this.txtpnetincome.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpnetincome.Location = new System.Drawing.Point(155, 219);
            this.txtpnetincome.Margin = new System.Windows.Forms.Padding(4);
            this.txtpnetincome.Name = "txtpnetincome";
            this.txtpnetincome.Size = new System.Drawing.Size(488, 64);
            this.txtpnetincome.TabIndex = 21;
            this.txtpnetincome.Text = "0";
            this.txtpnetincome.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.Location = new System.Drawing.Point(52, 223);
            this.Label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(106, 17);
            this.Label12.TabIndex = 21;
            this.Label12.Text = "Net revenue :";
            // 
            // GroupBox4
            // 
            this.GroupBox4.Controls.Add(this.txtpgincome);
            this.GroupBox4.Controls.Add(this.Label11);
            this.GroupBox4.Controls.Add(this.txtPholPayDay);
            this.GroupBox4.Controls.Add(this.txtPholPay);
            this.GroupBox4.Controls.Add(this.Label7);
            this.GroupBox4.Controls.Add(this.Label3);
            this.GroupBox4.Controls.Add(this.txtPregOt);
            this.GroupBox4.Controls.Add(this.txtPRegOtHr);
            this.GroupBox4.Controls.Add(this.Label8);
            this.GroupBox4.Controls.Add(this.Label4);
            this.GroupBox4.Location = new System.Drawing.Point(11, 90);
            this.GroupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.GroupBox4.Size = new System.Drawing.Size(640, 122);
            this.GroupBox4.TabIndex = 19;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "Additions";
            this.GroupBox4.Enter += new System.EventHandler(this.GroupBox4_Enter);
            // 
            // txtpgincome
            // 
            this.txtpgincome.Enabled = false;
            this.txtpgincome.Location = new System.Drawing.Point(456, 82);
            this.txtpgincome.Margin = new System.Windows.Forms.Padding(4);
            this.txtpgincome.Name = "txtpgincome";
            this.txtpgincome.Size = new System.Drawing.Size(176, 25);
            this.txtpgincome.TabIndex = 20;
            this.txtpgincome.Text = "0";
            this.txtpgincome.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Location = new System.Drawing.Point(333, 85);
            this.Label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(125, 17);
            this.Label11.TabIndex = 19;
            this.Label11.Text = "Gross revenue :";
            this.Label11.Click += new System.EventHandler(this.Label11_Click);
            // 
            // txtPholPayDay
            // 
            this.txtPholPayDay.Location = new System.Drawing.Point(162, 54);
            this.txtPholPayDay.Margin = new System.Windows.Forms.Padding(4);
            this.txtPholPayDay.Name = "txtPholPayDay";
            this.txtPholPayDay.Size = new System.Drawing.Size(176, 25);
            this.txtPholPayDay.TabIndex = 4;
            this.txtPholPayDay.TextChanged += new System.EventHandler(this.txtPholPayDay_TextChanged);
            // 
            // txtPholPay
            // 
            this.txtPholPay.Enabled = false;
            this.txtPholPay.Location = new System.Drawing.Point(456, 50);
            this.txtPholPay.Margin = new System.Windows.Forms.Padding(4);
            this.txtPholPay.Name = "txtPholPay";
            this.txtPholPay.Size = new System.Drawing.Size(176, 25);
            this.txtPholPay.TabIndex = 18;
            this.txtPholPay.Text = "0";
            this.txtPholPay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(339, 57);
            this.Label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(128, 17);
            this.Label7.TabIndex = 17;
            this.Label7.Text = "paidLeave total :";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(8, 22);
            this.Label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(115, 17);
            this.Label3.TabIndex = 3;
            this.Label3.Text = "overtime [hrs]:";
            // 
            // txtPregOt
            // 
            this.txtPregOt.Enabled = false;
            this.txtPregOt.Location = new System.Drawing.Point(456, 19);
            this.txtPregOt.Margin = new System.Windows.Forms.Padding(4);
            this.txtPregOt.Name = "txtPregOt";
            this.txtPregOt.Size = new System.Drawing.Size(176, 25);
            this.txtPregOt.TabIndex = 16;
            this.txtPregOt.Text = "0";
            this.txtPregOt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPregOt.TextChanged += new System.EventHandler(this.txtPregOt_TextChanged);
            // 
            // txtPRegOtHr
            // 
            this.txtPRegOtHr.Location = new System.Drawing.Point(162, 19);
            this.txtPRegOtHr.Margin = new System.Windows.Forms.Padding(4);
            this.txtPRegOtHr.Name = "txtPRegOtHr";
            this.txtPRegOtHr.Size = new System.Drawing.Size(176, 25);
            this.txtPRegOtHr.TabIndex = 3;
            this.txtPRegOtHr.TextChanged += new System.EventHandler(this.txtPRegOtHr_TextChanged);
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(364, 22);
            this.Label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(87, 17);
            this.Label8.TabIndex = 15;
            this.Label8.Text = "hour total :";
            this.Label8.Click += new System.EventHandler(this.Label8_Click);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(1, 58);
            this.Label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(136, 17);
            this.Label4.TabIndex = 5;
            this.Label4.Text = "Paid leave [days]:";
            this.Label4.Click += new System.EventHandler(this.Label4_Click);
            // 
            // txtPrateWage
            // 
            this.txtPrateWage.Enabled = false;
            this.txtPrateWage.Location = new System.Drawing.Point(471, 57);
            this.txtPrateWage.Margin = new System.Windows.Forms.Padding(4);
            this.txtPrateWage.Name = "txtPrateWage";
            this.txtPrateWage.Size = new System.Drawing.Size(176, 25);
            this.txtPrateWage.TabIndex = 14;
            this.txtPrateWage.Text = "0";
            this.txtPrateWage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(339, 58);
            this.Label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(94, 17);
            this.Label9.TabIndex = 13;
            this.Label9.Text = "Salary rate:";
            this.Label9.Click += new System.EventHandler(this.Label9_Click);
            // 
            // txtPRateperday
            // 
            this.txtPRateperday.Enabled = false;
            this.txtPRateperday.Location = new System.Drawing.Point(471, 26);
            this.txtPRateperday.Margin = new System.Windows.Forms.Padding(4);
            this.txtPRateperday.Name = "txtPRateperday";
            this.txtPRateperday.Size = new System.Drawing.Size(176, 25);
            this.txtPRateperday.TabIndex = 12;
            this.txtPRateperday.Text = "0";
            this.txtPRateperday.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(350, 26);
            this.Label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(111, 17);
            this.Label10.TabIndex = 11;
            this.Label10.Text = "Price per day:";
            this.Label10.Click += new System.EventHandler(this.Label10_Click);
            // 
            // txtPNoDays
            // 
            this.txtPNoDays.Location = new System.Drawing.Point(163, 55);
            this.txtPNoDays.Margin = new System.Windows.Forms.Padding(4);
            this.txtPNoDays.Name = "txtPNoDays";
            this.txtPNoDays.Size = new System.Drawing.Size(176, 25);
            this.txtPNoDays.TabIndex = 2;
            this.txtPNoDays.TextChanged += new System.EventHandler(this.txtPNoDays_TextChanged);
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(43, 60);
            this.Label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(80, 17);
            this.Label5.TabIndex = 9;
            this.Label5.Text = "No. days :";
            this.Label5.Click += new System.EventHandler(this.Label5_Click);
            // 
            // txtPPayPeriod
            // 
            this.txtPPayPeriod.Enabled = false;
            this.txtPPayPeriod.Location = new System.Drawing.Point(163, 23);
            this.txtPPayPeriod.Margin = new System.Windows.Forms.Padding(4);
            this.txtPPayPeriod.Name = "txtPPayPeriod";
            this.txtPPayPeriod.Size = new System.Drawing.Size(176, 25);
            this.txtPPayPeriod.TabIndex = 8;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(6, 26);
            this.Label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(138, 17);
            this.Label6.TabIndex = 7;
            this.Label6.Text = "Payment method :";
            this.Label6.Click += new System.EventHandler(this.Label6_Click);
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label19.Location = new System.Drawing.Point(13, 75);
            this.Label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(74, 17);
            this.Label19.TabIndex = 1;
            this.Label19.Text = "Search  :";
            this.Label19.Click += new System.EventHandler(this.Label19_Click);
            // 
            // txtTotaldeduc
            // 
            this.txtTotaldeduc.Location = new System.Drawing.Point(885, 87);
            this.txtTotaldeduc.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotaldeduc.Name = "txtTotaldeduc";
            this.txtTotaldeduc.Size = new System.Drawing.Size(132, 22);
            this.txtTotaldeduc.TabIndex = 31;
            this.txtTotaldeduc.Visible = false;
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.txtPAssignCode);
            this.GroupBox1.Controls.Add(this.txtPEmployeeName);
            this.GroupBox1.Controls.Add(this.Label2);
            this.GroupBox1.Controls.Add(this.Label1);
            this.GroupBox1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox1.Location = new System.Drawing.Point(20, 23);
            this.GroupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.GroupBox1.Size = new System.Drawing.Size(664, 100);
            this.GroupBox1.TabIndex = 0;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Employee Details";
            // 
            // txtPAssignCode
            // 
            this.txtPAssignCode.Location = new System.Drawing.Point(142, 26);
            this.txtPAssignCode.Margin = new System.Windows.Forms.Padding(4);
            this.txtPAssignCode.Name = "txtPAssignCode";
            this.txtPAssignCode.Size = new System.Drawing.Size(307, 25);
            this.txtPAssignCode.TabIndex = 1;
            this.txtPAssignCode.TextChanged += new System.EventHandler(this.txtPAssignCode_TextChanged);
            // 
            // txtPEmployeeName
            // 
            this.txtPEmployeeName.Enabled = false;
            this.txtPEmployeeName.Location = new System.Drawing.Point(142, 58);
            this.txtPEmployeeName.Margin = new System.Windows.Forms.Padding(4);
            this.txtPEmployeeName.Name = "txtPEmployeeName";
            this.txtPEmployeeName.Size = new System.Drawing.Size(432, 25);
            this.txtPEmployeeName.TabIndex = 2;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(18, 32);
            this.Label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(51, 17);
            this.Label2.TabIndex = 1;
            this.Label2.Text = "Code:";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(6, 61);
            this.Label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(128, 17);
            this.Label1.TabIndex = 0;
            this.Label1.Text = "Employee name:";
            this.Label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Location = new System.Drawing.Point(761, 81);
            this.Label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(78, 16);
            this.Label13.TabIndex = 28;
            this.Label13.Text = "Bread Vale:";
            // 
            // txttrancode
            // 
            this.txttrancode.Location = new System.Drawing.Point(759, 55);
            this.txttrancode.Margin = new System.Windows.Forms.Padding(4);
            this.txttrancode.Name = "txttrancode";
            this.txttrancode.Size = new System.Drawing.Size(132, 22);
            this.txttrancode.TabIndex = 3;
            // 
            // TabPage9
            // 
            this.TabPage9.Controls.Add(this.label20);
            this.TabPage9.Controls.Add(this.txtpsearch);
            this.TabPage9.Controls.Add(this.Label19);
            this.TabPage9.Controls.Add(this.dtgParollList);
            this.TabPage9.Location = new System.Drawing.Point(4, 25);
            this.TabPage9.Margin = new System.Windows.Forms.Padding(4);
            this.TabPage9.Name = "TabPage9";
            this.TabPage9.Padding = new System.Windows.Forms.Padding(4);
            this.TabPage9.Size = new System.Drawing.Size(1135, 615);
            this.TabPage9.TabIndex = 1;
            this.TabPage9.Text = "List";
            this.TabPage9.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(11, 17);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(74, 39);
            this.label20.TabIndex = 26;
            this.label20.Text = "List";
            // 
            // txtpsearch
            // 
            this.txtpsearch.Location = new System.Drawing.Point(126, 73);
            this.txtpsearch.Margin = new System.Windows.Forms.Padding(4);
            this.txtpsearch.Name = "txtpsearch";
            this.txtpsearch.Size = new System.Drawing.Size(256, 22);
            this.txtpsearch.TabIndex = 2;
            this.txtpsearch.TextChanged += new System.EventHandler(this.txtpsearch_TextChanged);
            // 
            // dtgParollList
            // 
            this.dtgParollList.AllowUserToAddRows = false;
            this.dtgParollList.AllowUserToDeleteRows = false;
            this.dtgParollList.AllowUserToResizeColumns = false;
            this.dtgParollList.AllowUserToResizeRows = false;
            this.dtgParollList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgParollList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgParollList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgParollList.Location = new System.Drawing.Point(5, 103);
            this.dtgParollList.Margin = new System.Windows.Forms.Padding(4);
            this.dtgParollList.Name = "dtgParollList";
            this.dtgParollList.RowHeadersVisible = false;
            this.dtgParollList.RowHeadersWidth = 51;
            this.dtgParollList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgParollList.Size = new System.Drawing.Size(1117, 459);
            this.dtgParollList.TabIndex = 0;
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Location = new System.Drawing.Point(19, 113);
            this.Label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(93, 17);
            this.Label15.TabIndex = 24;
            this.Label15.Text = "Transport : ";
            this.Label15.UseWaitCursor = true;
            this.Label15.Click += new System.EventHandler(this.Label15_Click);
            // 
            // TabControl3
            // 
            this.TabControl3.Controls.Add(this.TabPage8);
            this.TabControl3.Controls.Add(this.TabPage9);
            this.TabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabControl3.Location = new System.Drawing.Point(0, 0);
            this.TabControl3.Margin = new System.Windows.Forms.Padding(4);
            this.TabControl3.Name = "TabControl3";
            this.TabControl3.SelectedIndex = 0;
            this.TabControl3.Size = new System.Drawing.Size(1143, 644);
            this.TabControl3.TabIndex = 2;
            // 
            // TabPage8
            // 
            this.TabPage8.BackColor = System.Drawing.Color.Transparent;
            this.TabPage8.Controls.Add(this.PictureBox3);
            this.TabPage8.Controls.Add(this.txtbvale);
            this.TabPage8.Controls.Add(this.Button2);
            this.TabPage8.Controls.Add(this.btnPsave);
            this.TabPage8.Controls.Add(this.GroupBox2);
            this.TabPage8.Controls.Add(this.txtTotaldeduc);
            this.TabPage8.Controls.Add(this.GroupBox1);
            this.TabPage8.Controls.Add(this.Label13);
            this.TabPage8.Controls.Add(this.txttrancode);
            this.TabPage8.Location = new System.Drawing.Point(4, 25);
            this.TabPage8.Margin = new System.Windows.Forms.Padding(4);
            this.TabPage8.Name = "TabPage8";
            this.TabPage8.Padding = new System.Windows.Forms.Padding(4);
            this.TabPage8.Size = new System.Drawing.Size(1135, 615);
            this.TabPage8.TabIndex = 0;
            this.TabPage8.Text = "Create payroll";
            this.TabPage8.Click += new System.EventHandler(this.TabPage8_Click);
            // 
            // PictureBox3
            // 
            this.PictureBox3.Location = new System.Drawing.Point(715, 34);
            this.PictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(384, 87);
            this.PictureBox3.TabIndex = 32;
            this.PictureBox3.TabStop = false;
            // 
            // txtbvale
            // 
            this.txtbvale.Location = new System.Drawing.Point(885, 79);
            this.txtbvale.Margin = new System.Windows.Forms.Padding(4);
            this.txtbvale.Name = "txtbvale";
            this.txtbvale.Size = new System.Drawing.Size(176, 22);
            this.txtbvale.TabIndex = 6;
            // 
            // Button2
            // 
            this.Button2.BackColor = System.Drawing.Color.Silver;
            this.Button2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button2.Location = new System.Drawing.Point(923, 554);
            this.Button2.Margin = new System.Windows.Forms.Padding(4);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(157, 36);
            this.Button2.TabIndex = 19;
            this.Button2.Text = "Clear";
            this.Button2.UseVisualStyleBackColor = false;
            this.Button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // btnPsave
            // 
            this.btnPsave.BackColor = System.Drawing.Color.Silver;
            this.btnPsave.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPsave.Location = new System.Drawing.Point(740, 554);
            this.btnPsave.Margin = new System.Windows.Forms.Padding(4);
            this.btnPsave.Name = "btnPsave";
            this.btnPsave.Size = new System.Drawing.Size(175, 36);
            this.btnPsave.TabIndex = 18;
            this.btnPsave.Text = "REGISTER";
            this.btnPsave.UseVisualStyleBackColor = false;
            this.btnPsave.Click += new System.EventHandler(this.btnEnregistrer_Click);
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.GroupBox7);
            this.GroupBox2.Controls.Add(this.GroupBox5);
            this.GroupBox2.Controls.Add(this.GroupBox3);
            this.GroupBox2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox2.Location = new System.Drawing.Point(20, 129);
            this.GroupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.GroupBox2.Size = new System.Drawing.Size(1073, 475);
            this.GroupBox2.TabIndex = 1;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Pay details";
            // 
            // GroupBox7
            // 
            this.GroupBox7.Controls.Add(this.txtpremarks);
            this.GroupBox7.Location = new System.Drawing.Point(9, 348);
            this.GroupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.GroupBox7.Name = "GroupBox7";
            this.GroupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.GroupBox7.Size = new System.Drawing.Size(655, 108);
            this.GroupBox7.TabIndex = 4;
            this.GroupBox7.TabStop = false;
            this.GroupBox7.Text = "Remarks";
            // 
            // txtpremarks
            // 
            this.txtpremarks.Location = new System.Drawing.Point(12, 25);
            this.txtpremarks.Margin = new System.Windows.Forms.Padding(4);
            this.txtpremarks.Name = "txtpremarks";
            this.txtpremarks.Size = new System.Drawing.Size(631, 64);
            this.txtpremarks.TabIndex = 17;
            this.txtpremarks.Text = "";
            // 
            // GroupBox5
            // 
            this.GroupBox5.Controls.Add(this.GroupBox6);
            this.GroupBox5.Controls.Add(this.txtpcadvance);
            this.GroupBox5.Controls.Add(this.txtpphic);
            this.GroupBox5.Controls.Add(this.Label16);
            this.GroupBox5.Controls.Add(this.Label14);
            this.GroupBox5.Controls.Add(this.txtppagibig);
            this.GroupBox5.Controls.Add(this.Label15);
            this.GroupBox5.Location = new System.Drawing.Point(679, 22);
            this.GroupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.GroupBox5.Size = new System.Drawing.Size(387, 386);
            this.GroupBox5.TabIndex = 3;
            this.GroupBox5.TabStop = false;
            this.GroupBox5.Text = "Deductions ";
            this.GroupBox5.UseWaitCursor = true;
            this.GroupBox5.Enter += new System.EventHandler(this.GroupBox5_Enter);
            // 
            // GroupBox6
            // 
            this.GroupBox6.Controls.Add(this.Label18);
            this.GroupBox6.Controls.Add(this.txtpdeducttot);
            this.GroupBox6.Controls.Add(this.Label17);
            this.GroupBox6.Controls.Add(this.txtpdeduct4);
            this.GroupBox6.Controls.Add(this.txtpdeductname4);
            this.GroupBox6.Controls.Add(this.txtpdeduct3);
            this.GroupBox6.Controls.Add(this.txtpdeductname3);
            this.GroupBox6.Controls.Add(this.txtpdeduct2);
            this.GroupBox6.Controls.Add(this.txtpdeductname2);
            this.GroupBox6.Controls.Add(this.txtpdeduct1);
            this.GroupBox6.Controls.Add(this.txtpdeductname1);
            this.GroupBox6.Location = new System.Drawing.Point(8, 154);
            this.GroupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.GroupBox6.Name = "GroupBox6";
            this.GroupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.GroupBox6.Size = new System.Drawing.Size(373, 224);
            this.GroupBox6.TabIndex = 30;
            this.GroupBox6.TabStop = false;
            this.GroupBox6.Text = "Other Deductions";
            this.GroupBox6.UseWaitCursor = true;
            this.GroupBox6.Enter += new System.EventHandler(this.GroupBox6_Enter);
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Location = new System.Drawing.Point(15, 20);
            this.Label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(99, 17);
            this.Label18.TabIndex = 31;
            this.Label18.Text = "Deductions :";
            this.Label18.UseWaitCursor = true;
            // 
            // txtpdeducttot
            // 
            this.txtpdeducttot.Enabled = false;
            this.txtpdeducttot.Location = new System.Drawing.Point(193, 170);
            this.txtpdeducttot.Margin = new System.Windows.Forms.Padding(4);
            this.txtpdeducttot.Name = "txtpdeducttot";
            this.txtpdeducttot.Size = new System.Drawing.Size(176, 25);
            this.txtpdeducttot.TabIndex = 23;
            this.txtpdeducttot.Text = "0";
            this.txtpdeducttot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpdeducttot.UseWaitCursor = true;
            this.txtpdeducttot.TextChanged += new System.EventHandler(this.txtpdeducttot_TextChanged);
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Location = new System.Drawing.Point(127, 172);
            this.Label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(53, 17);
            this.Label17.TabIndex = 22;
            this.Label17.Text = "Total :";
            this.Label17.UseWaitCursor = true;
            // 
            // txtpdeduct4
            // 
            this.txtpdeduct4.Location = new System.Drawing.Point(193, 137);
            this.txtpdeduct4.Margin = new System.Windows.Forms.Padding(4);
            this.txtpdeduct4.Name = "txtpdeduct4";
            this.txtpdeduct4.Size = new System.Drawing.Size(176, 25);
            this.txtpdeduct4.TabIndex = 16;
            this.txtpdeduct4.Text = "0";
            this.txtpdeduct4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpdeduct4.UseWaitCursor = true;
            this.txtpdeduct4.TextChanged += new System.EventHandler(this.txtpdeduct4_TextChanged);
            // 
            // txtpdeductname4
            // 
            this.txtpdeductname4.Location = new System.Drawing.Point(8, 137);
            this.txtpdeductname4.Margin = new System.Windows.Forms.Padding(4);
            this.txtpdeductname4.Name = "txtpdeductname4";
            this.txtpdeductname4.Size = new System.Drawing.Size(176, 25);
            this.txtpdeductname4.TabIndex = 15;
            this.txtpdeductname4.UseWaitCursor = true;
            // 
            // txtpdeduct3
            // 
            this.txtpdeduct3.Location = new System.Drawing.Point(193, 105);
            this.txtpdeduct3.Margin = new System.Windows.Forms.Padding(4);
            this.txtpdeduct3.Name = "txtpdeduct3";
            this.txtpdeduct3.Size = new System.Drawing.Size(176, 25);
            this.txtpdeduct3.TabIndex = 14;
            this.txtpdeduct3.Text = "0";
            this.txtpdeduct3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpdeduct3.UseWaitCursor = true;
            this.txtpdeduct3.TextChanged += new System.EventHandler(this.txtpdeduct3_TextChanged);
            // 
            // txtpdeductname3
            // 
            this.txtpdeductname3.Location = new System.Drawing.Point(8, 105);
            this.txtpdeductname3.Margin = new System.Windows.Forms.Padding(4);
            this.txtpdeductname3.Name = "txtpdeductname3";
            this.txtpdeductname3.Size = new System.Drawing.Size(176, 25);
            this.txtpdeductname3.TabIndex = 13;
            this.txtpdeductname3.Text = "0";
            this.txtpdeductname3.UseWaitCursor = true;
            // 
            // txtpdeduct2
            // 
            this.txtpdeduct2.Location = new System.Drawing.Point(193, 73);
            this.txtpdeduct2.Margin = new System.Windows.Forms.Padding(4);
            this.txtpdeduct2.Name = "txtpdeduct2";
            this.txtpdeduct2.Size = new System.Drawing.Size(176, 25);
            this.txtpdeduct2.TabIndex = 12;
            this.txtpdeduct2.Text = "0";
            this.txtpdeduct2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpdeduct2.UseWaitCursor = true;
            this.txtpdeduct2.TextChanged += new System.EventHandler(this.txtpdeduct2_TextChanged);
            // 
            // txtpdeductname2
            // 
            this.txtpdeductname2.Location = new System.Drawing.Point(8, 73);
            this.txtpdeductname2.Margin = new System.Windows.Forms.Padding(4);
            this.txtpdeductname2.Name = "txtpdeductname2";
            this.txtpdeductname2.Size = new System.Drawing.Size(176, 25);
            this.txtpdeductname2.TabIndex = 11;
            this.txtpdeductname2.UseWaitCursor = true;
            // 
            // txtpdeduct1
            // 
            this.txtpdeduct1.Location = new System.Drawing.Point(193, 41);
            this.txtpdeduct1.Margin = new System.Windows.Forms.Padding(4);
            this.txtpdeduct1.Name = "txtpdeduct1";
            this.txtpdeduct1.Size = new System.Drawing.Size(176, 25);
            this.txtpdeduct1.TabIndex = 10;
            this.txtpdeduct1.Text = "0";
            this.txtpdeduct1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpdeduct1.UseWaitCursor = true;
            this.txtpdeduct1.TextChanged += new System.EventHandler(this.txtpdeduct1_TextChanged);
            // 
            // txtpdeductname1
            // 
            this.txtpdeductname1.Location = new System.Drawing.Point(8, 41);
            this.txtpdeductname1.Margin = new System.Windows.Forms.Padding(4);
            this.txtpdeductname1.Name = "txtpdeductname1";
            this.txtpdeductname1.Size = new System.Drawing.Size(176, 25);
            this.txtpdeductname1.TabIndex = 9;
            this.txtpdeductname1.UseWaitCursor = true;
            // 
            // txtpcadvance
            // 
            this.txtpcadvance.Location = new System.Drawing.Point(143, 43);
            this.txtpcadvance.Margin = new System.Windows.Forms.Padding(4);
            this.txtpcadvance.Name = "txtpcadvance";
            this.txtpcadvance.Size = new System.Drawing.Size(176, 25);
            this.txtpcadvance.TabIndex = 5;
            this.txtpcadvance.Text = "0";
            this.txtpcadvance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpcadvance.UseWaitCursor = true;
            this.txtpcadvance.TextChanged += new System.EventHandler(this.txtpcadvance_TextChanged);
            // 
            // txtpphic
            // 
            this.txtpphic.Location = new System.Drawing.Point(143, 78);
            this.txtpphic.Margin = new System.Windows.Forms.Padding(4);
            this.txtpphic.Name = "txtpphic";
            this.txtpphic.Size = new System.Drawing.Size(176, 25);
            this.txtpphic.TabIndex = 7;
            this.txtpphic.Text = "0";
            this.txtpphic.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtpphic.UseWaitCursor = true;
            this.txtpphic.TextChanged += new System.EventHandler(this.txtpphic_TextChanged);
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Location = new System.Drawing.Point(19, 80);
            this.Label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(40, 17);
            this.Label16.TabIndex = 22;
            this.Label16.Text = "PF : ";
            this.Label16.UseWaitCursor = true;
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Location = new System.Drawing.Point(19, 43);
            this.Label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(81, 17);
            this.Label14.TabIndex = 26;
            this.Label14.Text = "Advance :";
            this.Label14.UseWaitCursor = true;
            // 
            // frm_Paie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1143, 644);
            this.Controls.Add(this.TabControl3);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_Paie";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Payments";
            this.Load += new System.EventHandler(this.frm_Paie_Load);
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            this.GroupBox4.ResumeLayout(false);
            this.GroupBox4.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.TabPage9.ResumeLayout(false);
            this.TabPage9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgParollList)).EndInit();
            this.TabControl3.ResumeLayout(false);
            this.TabPage8.ResumeLayout(false);
            this.TabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox7.ResumeLayout(false);
            this.GroupBox5.ResumeLayout(false);
            this.GroupBox5.PerformLayout();
            this.GroupBox6.ResumeLayout(false);
            this.GroupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.TextBox txtppagibig;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.TextBox txtpnetincome;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.GroupBox GroupBox4;
        internal System.Windows.Forms.TextBox txtpgincome;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.TextBox txtPholPayDay;
        internal System.Windows.Forms.TextBox txtPholPay;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox txtPregOt;
        internal System.Windows.Forms.TextBox txtPRegOtHr;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox txtPrateWage;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.TextBox txtPRateperday;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.TextBox txtPNoDays;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox txtPPayPeriod;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.TextBox txtTotaldeduc;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.DomainUpDown txtPAssignCode;
        internal System.Windows.Forms.TextBox txtPEmployeeName;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.TextBox txttrancode;
        internal System.Windows.Forms.TabPage TabPage9;
        internal System.Windows.Forms.TextBox txtpsearch;
        internal System.Windows.Forms.DataGridView dtgParollList;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.TabControl TabControl3;
        internal System.Windows.Forms.TabPage TabPage8;
        internal System.Windows.Forms.PictureBox PictureBox3;
        internal System.Windows.Forms.TextBox txtbvale;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.Button btnPsave;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.GroupBox GroupBox7;
        internal System.Windows.Forms.RichTextBox txtpremarks;
        internal System.Windows.Forms.GroupBox GroupBox5;
        internal System.Windows.Forms.GroupBox GroupBox6;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.TextBox txtpdeducttot;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.TextBox txtpdeduct4;
        internal System.Windows.Forms.TextBox txtpdeductname4;
        internal System.Windows.Forms.TextBox txtpdeduct3;
        internal System.Windows.Forms.TextBox txtpdeductname3;
        internal System.Windows.Forms.TextBox txtpdeduct2;
        internal System.Windows.Forms.TextBox txtpdeductname2;
        internal System.Windows.Forms.TextBox txtpdeduct1;
        internal System.Windows.Forms.TextBox txtpdeductname1;
        internal System.Windows.Forms.TextBox txtpcadvance;
        internal System.Windows.Forms.TextBox txtpphic;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Label Label14;
        private System.Windows.Forms.Label label20;
    }
}